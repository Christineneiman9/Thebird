---
layout: it-IT/default
title: Tradurre rust-lang.org in altri linguaggi per adottare l'internazionalizzazione 
---

# Rust è universale

Manca la documentazione su come contribuire a tradurre!
