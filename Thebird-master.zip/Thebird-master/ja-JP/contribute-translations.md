---
layout: ja-JP/default
title: rust-lang.orgを他言語へ翻訳して国際化する
---

# Rustはユニバーサル

翻訳についての貢献について書く。
