---
layout: ru-RU/untranslated
title: Contributing to Rust &mdash; language, compiler, and the standard library &middot; The Rust Programming Language
---
