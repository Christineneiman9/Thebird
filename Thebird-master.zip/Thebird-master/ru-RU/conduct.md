---
layout: ru-RU/untranslated
title: The Rust Code of Conduct &middot; The Rust Programming Language
---
