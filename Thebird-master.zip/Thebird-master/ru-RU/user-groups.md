---
layout: ru-RU/untranslated
title: Rust User Groups &middot; The Rust Programming Language
---

## Indonesia

[Rust Indonesia](https://github.com/rustid/meetup), Yogyakarta.
