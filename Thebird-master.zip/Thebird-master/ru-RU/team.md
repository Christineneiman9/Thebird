---
layout: ru-RU/untranslated
title: The Rust Team &middot; The Rust Programming Language
---
