---
layout: ru-RU/untranslated
title: Rust Legal Policies &middot; The Rust Programming Language
---
