---
layout: ru-RU/faq
title: Frequently Asked Questions &middot; The Rust Programming Language
---
