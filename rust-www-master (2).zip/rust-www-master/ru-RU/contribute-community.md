---
layout: ru-RU/untranslated
title: Contributing to Rust &mdash; community building &middot; The Rust Programming Language
---
