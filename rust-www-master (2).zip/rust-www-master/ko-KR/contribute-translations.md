---
layout: ko-KR/default
title: Translating rust-lang.org to other languages to adapt internationalization 
---

# Rust is universal

Some docs on contributing translations!
