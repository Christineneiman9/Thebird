---
layout: ru-RU/basic
---

<div class="content">
  <b>Внимание</b>: эта страница ещё не переведена на русский язык.
  Вы можете <a href={{ page.url | replace: ".html", ".md" | prepend: "https://github.com/rust-lang/rust-www/edit/master/" }}>помочь с переводом</a>
  или читать <a href={{ page.url | replace: "/ru-RU/", "/en-US/" }}>английскую версию</a>.
</div>
